# Requirements Coverage - Version 5.2.1

The application covers the agreed analytical requirements and contains additional capabilities without changing or reducing the original scope.

| Area | Implemented coverage |
|---|---|
| Data | Multiple XLSX/XLS/CSV/TSV files, all sheets, separate/append/join, lineage, header repair and audit |
| Scale | Up to 1,000 dependent and 1,000 independent variables in the batch screen |
| Statistics | Descriptive summaries, correlations, group/categorical/normality tests and effect sizes |
| Econometrics | OLS/WLS/Huber, binary/count/fractional/Gamma/quantile models, robust/HAC/clustered inference, IV, DiD and regularisation |
| Uncertainty | Monte Carlo OLS and stochastic project-portfolio selection |
| Panel | Original R&D region-year models and pooled/FE/RE/Hausman suite |
| Spatial | Greece NUTS-2/NUTS-3 mapping, Moran/LISA and publication maps |
| Multivariate | PCA, reliability, time series, legacy and advanced clustering |
| Prediction | Seven cross-validated models and permutation importance |
| Decision support | Scenario projection, constrained allocation and dedicated MCDA |
| MCDA | MAVT, TOPSIS, PROMETHEE II, five weight systems, AHP consistency, sensitivity and rank acceptability |
| Outputs | CSV/XLSX, self-contained HTML, colour/B&W PNG 600 dpi, SVG and PDF |
| Reproducibility | Seeds, diagnostics, methods catalogue, source manifest, tests and release documentation |

The forthcoming 2,000-project renewable-energy file can be ingested by this release. New code is not automatically required; data-specific recoding, spatial keys and validated criteria will be configured after receipt.

